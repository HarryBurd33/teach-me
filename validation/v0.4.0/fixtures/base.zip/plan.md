# Synthetic logic plan
Baseline target: explain joint premises.
