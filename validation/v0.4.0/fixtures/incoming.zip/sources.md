# Sources
Incoming source clarification; synthetic only.
